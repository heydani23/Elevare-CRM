Elevare CRM — Free PWA Wrapper

FILES
- index.html — loads your Softr app inside the app (best experience)
- index_redirect.html — use this if your Softr link blocks iframe embedding
- manifest.json — makes this installable as a PWA
- service-worker.js — basic offline support
- icon-512.png — app icon
- offline.html — offline message

HOW TO DEPLOY (free, iPad-only possible)
1) Upload these 6 files to a GitHub repo (or Netlify/Vercel).
2) If iframe fails (blank screen), rename index_redirect.html to index.html and re-upload.
3) Open the site in Safari on iPad → Share → Add to Home Screen → Add.
4) You’ll get a full-screen app icon launching Elevare CRM.

NOTE
- External links may open in Safari (normal).
- For the very best standalone behavior, publish Softr in PWA mode when possible.
