self.addEventListener('install', event => {
  event.waitUntil(
    caches.open('elevare-cache-v1').then(cache => cache.addAll([
      './',
      './index.html',
      './manifest.json',
      './icon-512.png',
      './offline.html'
    ]))
  );
});
self.addEventListener('fetch', event => {
  event.respondWith(
    fetch(event.request).catch(() => caches.match('offline.html'))
  );
});